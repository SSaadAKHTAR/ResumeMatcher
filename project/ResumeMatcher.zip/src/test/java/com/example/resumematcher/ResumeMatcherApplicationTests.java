package com.example.resumematcher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumeMatcherApplicationTests {

	@Test
	void contextLoads() {
	}

}
